﻿using System;

[Serializable]
public class HPInfo
{
    public string hpName;
    public WeaponType;
    public Objective (40 30) 
		{ "Your Mission Is To Scramble as much Fighters as Possible...." }
	{
        this.hpName = hpName
        this.WeaponType = 0x1000 : 0x1001 : 0x1010 : 0x1011 : 0x1111
    	}
}